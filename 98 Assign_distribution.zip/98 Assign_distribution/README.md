ไฟล์ input ต้องมี 2 ไฟล์ คือ  .CSV / .xlsx  มีแค่ sheet เดียว
1. ไฟล์ oa สำหรับ assign ใส่ใน folder   assigned
2. ไฟล์ AR ที่ต้องการ assign ใส่ใน folder AR ชื่ออะไรก้อได้ มีกี่ column ก้อได้ แต่ต้องมี column loan_balance และ loan_no

ไฟล์ output จะชื่อ   oa_distribution_{ชื่อไฟล์ ar} 